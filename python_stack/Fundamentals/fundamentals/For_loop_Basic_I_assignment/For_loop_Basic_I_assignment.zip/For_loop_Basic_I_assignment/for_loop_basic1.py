#########
#Basic

#for i in range(151):
#    print(i)

#########

#Multiples of Five

#for i in range(5,1000,5):
#    print(i)

#########

#Counting the Dojo Way

#for i in range (1,101):
#    if i % 10 == 0:
#        print("Coding Dojo")
#    elif i % 5 == 0:
#        print("Coding")
#    else:
#        print(i)

########

#Whoa. That Sucker's Huge

#total = 0
#for i in range (0,500000,2):
#        total = total + i
#print(total)

########

#Countdown by Fours

#for i in range (2018,0,-4):
#    print(i)

########

#Flexible Counter

#lowNum = 4
#highNum = 21
#mult = 2

#for num in range (lowNum,highNum):
#    if num % mult == 0:
#       print(num)