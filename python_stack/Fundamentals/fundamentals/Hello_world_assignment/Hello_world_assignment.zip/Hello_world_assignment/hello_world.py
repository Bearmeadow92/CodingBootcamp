
print("Hello World")

name = "Jesse"
print("Hello " + name)
print("Hello", name)

name = 42
print("Hello", name)

fave_food1 = "sushi"
fave_food2 = "pizza"
print("I love {} and {}.".format(fave_food1, fave_food2))
print(f"I love {fave_food1} and {fave_food2} ")