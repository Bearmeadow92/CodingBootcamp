public class First {
    public static void main(String[] args){
        System.out.println("My name is Jesse Fletcher");
        System.out.println("I am 30 years old");
        System.out.println("My hometown is Reno NV");
    }
}

