import React from 'react';
// import './App.css';

const Home = () => {
    return (
        <div style={{ textAlign: "center"}}>
            <h1>Welcome</h1>
        </div>
    )
}

export default Home;