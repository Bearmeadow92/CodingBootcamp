import React from 'react';
import { useParams } from "react-router";

const Word = (props) => {
    const {word, textColor, backColor} = useParams();
    console.log(textColor)
    return(
        <div>
        {
            (!isNaN(word))
            ? <h1 style={{ textAlign: "center" }}> This number is: {word}</h1>
            : (textColor || backColor)
                ? <h1 style={{ color: textColor, backgroundColor: backColor, textAlign: "center"}}>The word is: {word}</h1>
                : <h1 style={{ textAlign: "center" }}> The word is: {word}
                </h1>
        }
        </div>
    );
};

export default Word;

