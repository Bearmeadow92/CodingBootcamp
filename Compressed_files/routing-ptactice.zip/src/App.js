import './App.css';
import {BrowserRouter, Route, Switch} from 'react-router-dom'
import Home from './components/Home';
import Word from './components/Word';

function App() {
  return (
    <BrowserRouter>
      <div>
        <Switch>
          <Route path ="/home">
            <Home/>
          </Route>
          <Route path="/:word/:textColor/:backColor">
            <Word/>
          </Route>
          <Route path="/:word">
            <Word/>
          </Route>
        </Switch>
      </div>
    </BrowserRouter>
  );
}

export default App;
