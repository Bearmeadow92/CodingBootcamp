import React from "react";
import {BrowserRouter, Route, Routes} from "react-router-dom";
import SwForm from './components/SwForm';
import People from './views/People';
import Planets from './views/Planet';

    
function App() {
  return (
    <BrowserRouter>
    <fieldset>
      <SwForm/>
        <legend>App.js</legend>
      <Routes>
        <Route path="/"/>
        <Route path="/people/:id" element={<People/>}/>
        <Route path="/planets/:id" element={<Planets/>}/>
      </Routes>
      </fieldset>
    </BrowserRouter>
  );
}
    


export default App;
