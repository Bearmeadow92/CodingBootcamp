import React, {useEffect, useState} from 'react'
import { useParams } from 'react-router-dom'
import axios from 'axios'
// import SwForm from './components/SwForm'

const People = () => {
    const [people, setPeople] = useState()
    // const [homeworld, setHomeworld] = useState()
    const {id} = useParams()

    useEffect(() => {
        axios.get("https://swapi.dev/api/people/"+id)
            .then(res => {
                console.log(res.data)
                setPeople(res.data)
            })
            .catch(err => console.log(err))
    }, [id])

    // useEffect(() => {
    // axios.getHomeworld("https://swapi.dev/api/homeworld/"+id)
    // .then(res => {
    //     console.log(res.data)
    //     setHomeworld(res.data);
    // })
    // .catch(err => console.log(err))
    // }, [id])


    return (
        <div>
            {
            
                people ?
                // homeworld&& 
                <>
                    <h1>{people.name}</h1>
                    <p>Height: {people.height} cm</p>
                    <p>Mass: {people.mass} kg</p>
                    <p>Hair Color: {people.hair_color}</p>
                    <p>Skin Color: {people.skin_color}</p>
                    {/* <p>Homeworld: {homeworld.people}</p> */}
                </> : null
            }  
        </div>
    )
}

export default People;
