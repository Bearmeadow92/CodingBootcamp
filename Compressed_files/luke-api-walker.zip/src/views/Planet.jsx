import React, {useEffect, useState} from 'react'
import { useParams } from 'react-router-dom'
import axios from 'axios'
// import SwForm from './components/SwForm'

const Planets = () =>{
    const [planet, setPlanet] = useState()
    const {id} = useParams()




    //call api using .get//
    useEffect(() => {
        axios.get("https://swapi.dev/api/planets/"+id)
            .then(res => {
                console.log(res.data)
                setPlanet(res.data)
            })
            .catch(err => console.log(err))
    }, [id])




    return (
        <div>
            {
                planet ?
                <fieldset>
                    <h1>{planet.name}</h1>
                    <p>Climate:{planet.climate}</p>
                    <p>Terrain:{planet.terrain}</p>
                    <p>Surface Water:{planet.surface_water}</p>
                    <p>Population:{planet.population}</p>
                </fieldset> : null
            } 
            
        </div>
    )
}

export default Planets;