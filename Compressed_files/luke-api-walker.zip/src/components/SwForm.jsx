import React, {useState} from 'react'
import {Outlet, useNavigate } from 'react-router-dom'
      



const SwForm = () => {
        //STATE FOR KEEPING TRACK OF Name
      const [swName, setSwName] = useState("people")
      const [id, setId] = useState("")




        //Call the useNavigate function
      const navigate = useNavigate()




      //submit function for form
      const handleSubmit = (e) => {
            e.preventDefault()
            {
            swName === "people"
            ?navigate("/people/" + id)
            :navigate("/planets/" + id)
            }
      }



      //form html
      return(
      <fieldset>
            <legend>SwForm.jsx</legend>
                  <form onSubmit = {handleSubmit}>
                        <p>Search for:</p>
                              <select onChange={(e) => setSwName(e.target.value)} name="SwName">
                                    <option value="people">People</option>
                                    <option value="planets">Planets</option>
                              </select>
                        <p>ID:</p>
                              <input onChange={(e) => setId(e.target.value)} type="text" name="id"/>
                                    <button>Search</button>
                        
                  </form>
                  <Outlet/>
            </fieldset>
      )
}




      export default SwForm