import React, { Component } from 'react';

class PersonCard extends Component {

    constructor(props){
    super(props);
    const{age} = this.props;
    this.state={
        increment: age
    }
    }

    increaseAge = () =>{
        let{increment} = this.state;
        this.setState({
            increment: increment +1
        })
        console.log(this.state.increment)
    }

    render() {
        const {lastName, firstName, hairColor} = this.props;
        return (
            <div>
                <h1>{lastName}, {firstName}</h1>
                <p>Age: {this.state.increment}</p>
                <p>Hair Color: {hairColor}</p>
                <button onClick = {this.increaseAge} >Birthday Button for {firstName} {lastName}</button>
            </div>
        );
    }
}

export default PersonCard;