import React, { useEffect, useState } from 'react';
import ProductForm from "../components/ProductForm";
import Dashboard from '../components/Dashboard';





const Main = () => {
    return(
        <div>
            <ProductForm/>
            <Dashboard/>
        </div>
    )
}


export default Main