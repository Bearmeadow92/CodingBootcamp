import React from "react";
// import { BrowserRouter, Route, Routes } from "react-router-dom";
import ProductForm from "./components/ProductForm";
import Main from "./views/Main";
// import axios from 'axios'


//paths//
function App() {
  return (
  
    <div>
      <Main/>
    </div>
  );
}

export default App;
