import React, { useState } from 'react';
import axios from 'axios'

    
    
const ProductForm = () => {
    //DECLARE STATE
    const [title, setTitle] = useState("");
    const [price, setPrice] = useState(0);
    const [description, setDescription] = useState("");


    //HANDLER FUNCTIONS
    const submitHandler = event => {
        event.preventDefault();
        //CREATE AND OBJECT WITH THE PRODUCT INFO
        const productObj= {
            title,
            price,
            description
        }
        //MAKE POST REQUEST TO EXPRESS WITH productObj
        axios.post("http://localhost:8000/api/products", productObj)
        .then(res => console.log(res))
        .catch(err => console.log(err))
    }




    return(
        <fieldset>
            <form onSubmit={submitHandler}>
                <h1>Product Manager</h1>
                <div>
                    <label>title: </label> 
                    <input type="text" name="title"onChange={(e) => setTitle(e.target.value)} id=""/>
                </div>
                <div>
                    <label>price: </label> 
                    <input type="number" name="price" onChange={(e) => setPrice(e.target.value)}id=""/>
                </div>
                <div>
                    <label>description: </label> 
                    <input type="text" name="description" onChange={(e) => setDescription(e.target.value) } id=""/>
                </div>
                <button>Create</button>
            </form>
        </fieldset>
    );
};

export default ProductForm