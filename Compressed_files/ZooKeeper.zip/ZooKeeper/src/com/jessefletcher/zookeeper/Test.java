package com.jessefletcher.zookeeper;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Gorilla gorilla = new Gorilla();
		
		gorilla.throwSomething();
		gorilla.throwSomething();
		gorilla.throwSomething();
		System.out.println("Energy level is " + gorilla.displayEnergy());
		gorilla.eatBananas();
		gorilla.eatBananas();
		System.out.println("Energy level is " + gorilla.displayEnergy());
		gorilla.climb();
		System.out.println("Energy level is " + gorilla.displayEnergy());
		
	}
	
	
	
}
