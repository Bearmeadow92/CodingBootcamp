package com.jessefletcher.zookeeper;

public class Gorilla extends Mammal{
	//MEMBER VARIABLES
	
	
	
	
	
	//METHODS
	public void throwSomething() {
		System.out.println("Gorilla throws something!");
		this.energyLevel -= 5;
		return;
	}
	
	public void eatBananas() {
		System.out.println("Gorilla ate nanner!");
		System.out.println("MMM! BANANA DELICIOUS!");
		this.energyLevel += 10;
	}
	
	public void climb() {
		System.out.println("Gorilla climb!");
		this.energyLevel -= 10;
		
	}
}
