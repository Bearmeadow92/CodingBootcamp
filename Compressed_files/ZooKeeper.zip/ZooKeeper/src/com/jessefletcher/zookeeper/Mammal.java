package com.jessefletcher.zookeeper;

public class Mammal {
	//MEMBER VARIABLES
	public int energyLevel = 100;
	
	//METHODS
	public int displayEnergy(){
		return energyLevel;
	}
}
