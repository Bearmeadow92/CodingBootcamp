
//problem 1//

//Tesla

//Mercedes


//problem 2//

//It will error out



//problem 3//
//12345
//undefined

//problem 4//
//false
//true

//problem 5//
// value
// [ 1, 5, 1, 8, 3, 3 ]
// 1
// 5


