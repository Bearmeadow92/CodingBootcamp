import React, { useEffect, useState } from 'react';
import ProductForm from "../components/ProductForm";
import Dashboard from '../components/Dashboard';





const Main = () => {


    //STATE TO KEEP TRACK OF REFRESH
    const [refreshState, setRefresh] = useState(false)

    const refresh = () => {
        setRefresh(!refreshState)
    }



    return(
        <div>
            <legend>Main.jsx</legend>
            <ProductForm refresh={refresh}/>
            <Dashboard refreshState={refreshState}/>
        </div>
    )
}


export default Main