import React, { useEffect, useState} from 'react'
import axios from 'axios'
import { Link } from 'react-router-dom'

const Dashboard = (props) => {
    //STATE TO HOLD ALL PRODUCTS COMING FROM DATABASE
    const [allProducts, setAllProducts] = useState([])
    
    const {refreshState} = props


    useEffect(() => {
        axios.get("http://localhost:8000/api/products")
        .then(res => {setAllProducts(res.data)})//INCOMING PRODUCTS ARE SET TO STATE
        .catch(err => console.log(err))
    }, [refreshState])



    return(
        <fieldset>
            <div>
            <legend>DashboardComponent.jsx</legend>
            {
                allProducts.map((product, index) => {
                    return(
                        <div key={index}>
                            <Link to={"/" + product._id}>
                                <h1>{product.title}</h1>
                            </Link>
                        </div>
                    )
                })
            }
            </div>
        </fieldset>
    )
}

export default Dashboard