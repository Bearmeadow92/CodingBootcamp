import React, { useState } from 'react';
import axios from 'axios'

    
    
const ProductForm = (props) => {
    //DECLARE STATE
    const [title, setTitle] = useState("");
    const [price, setPrice] = useState(0);
    const [description, setDescription] = useState("");

    //DESTRUCTURE
    const {refresh} = props 

    //HANDLER FUNCTIONS
    const submitHandler = event => {
        event.preventDefault();
        //CREATE AND OBJECT WITH THE PRODUCT INFO
        const productObj= {
            title,
            price,
            description
        }
        //MAKE POST REQUEST TO EXPRESS WITH productObj
        axios.post("http://localhost:8000/api/products", productObj)
        .then(res => {
                    refresh()
                    setTitle("")
                    setPrice(0)
                    setDescription("")
                })
        .catch(err => console.log(err))
    }




    return(
        <fieldset>
            <legend>ProductForm.jsx</legend>
            <form onSubmit={submitHandler}>
                <h1>Product Manager</h1>
                <div>
                    <label>title: </label> 
                    <input type="text" name="title"onChange={(e) => setTitle(e.target.value)}value={title}/>
                </div>
                <div>
                    <label>price: </label> 
                    <input type="number" name="price" onChange={(e) => setPrice(e.target.value)}value={price}/>
                </div>
                <div>
                    <label>description: </label> 
                    <input type="text" name="description" onChange={(e) => setDescription(e.target.value) } value={description}/>
                </div>
                <button>Create</button>
            </form>
        </fieldset>
    );
};

export default ProductForm