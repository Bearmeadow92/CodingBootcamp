package com.jessefletcher.zookeeperII;

public class Mammal {
	//MEMBER VARIABLES
	public int energyLevel = 300;
	
	//METHODS
	public int displayEnergy(){
		return energyLevel;
	}

}
