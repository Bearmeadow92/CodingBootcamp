package com.jessefletcher.zookeeperII;


public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Bat bat = new Bat();
		
		bat.attackTown();
		bat.fly();
		bat.fly();
		System.out.println("Energy level is " + bat.displayEnergy());
		bat.eatHumans();
		bat.eatHumans();
		System.out.println("Energy level is " + bat.displayEnergy());
		bat.attackTown();
		bat.attackTown();
		System.out.println("Energy level is " + bat.displayEnergy());
	}

}
