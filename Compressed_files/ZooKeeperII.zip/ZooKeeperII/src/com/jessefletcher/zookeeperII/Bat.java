package com.jessefletcher.zookeeperII;

public class Bat extends Mammal {
	//METHODS
	public void fly() {
		System.out.println("WOOSH!");
		this.energyLevel -= 50;
		return;
	}
	
	public void eatHumans() {
		
		this.energyLevel += 25;
	}
	
	public void attackTown() {
		System.out.println("cracklecracklecrackle");
		this.energyLevel -= 100;
		
	}
}
