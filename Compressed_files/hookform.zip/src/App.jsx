import React, { useState } from 'react';
import UserForm from './components/UserForm';
import DisplayForm from './components/DisplayForm';
import './App.css';

function App() {
  const [state, setState] = useState({
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    confirmPassword: "",
  });

  const [users, setUsers] = useState([]) 


  return (
    <div className="App">
        <UserForm state={state} setState={setState}  users={users} setUsers={setUsers}/>
        <DisplayForm state={state} users={users}/>
    </div>
  );
}


export default App;