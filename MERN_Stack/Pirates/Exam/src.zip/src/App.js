import React from "react";
import {BrowserRouter, Routes, Route} from "react-router-dom";
import Main from "./views/Main";
import Detail from "./views/Detail";
import Create from "./views/Create";
// import axios from 'axios'


//paths//
function App() {
  return (
    <BrowserRouter>
      <fieldset>
          <div>
            <legend>App.jsx</legend>
            <Routes>
              <Route path="/" element={<Main/>}/>
              
              <Route path="/:pirate_id" element={<Detail/>}/>
              <Route path='/:pirate_id/create' element={<Create/>}/>
            </Routes>
          </div>
      </fieldset>
    </BrowserRouter>
  );
}

export default App;
