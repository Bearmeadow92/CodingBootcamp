import React from 'react'
import CreateForm from '../components/CreateForm'
const Create = () => {





  return (
    <fieldset>
        <legend>Create.jsx</legend>
        <CreateForm/>
    </fieldset>
  )
}

export default Create