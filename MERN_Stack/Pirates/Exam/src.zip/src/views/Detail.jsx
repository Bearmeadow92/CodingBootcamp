import React, {useEffect,useState} from 'react' 
import axios from "axios"
import {useParams, Link} from "react-router-dom"


const Detail = () => {
    // const navigate = useNavigate()
    //STATE FOR ONE PRODUCT
    const[pirate, setPirate] = useState()

    const {pirate_id} = useParams()

    useEffect(() => {
        axios.get("http://localhost:8000/api/pirates/" +pirate_id)
            .then(res => setPirate(res.data))
            .catch(err => console.log(err))
    },[])

    // const deleteHandler = (id) => {
    //     axios.delete("http://localhost:8000/api/pirates/"+id)
    //     .then(res => navigate("/"))
    //     .catch()
    // }


    return (
        <fieldset>
            {
                (pirate) ?
            <div>
                <Link to={'/'}><button>Crew Board</button></Link>
            <h1>{pirate.name}</h1>
            <img src={pirate.image_url} value="{name}"></img>
            <h2>"{pirate.catchPhrase}"</h2>
            <table>
                <thead>
                    <tr>
                        <td><h4>About</h4></td>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Position:</td>
                        <td>{pirate.crewPosition}</td>
                    </tr>
                    <tr>
                        <td>Treasures:</td>
                        <td>{pirate.treasureChests}</td>
                    </tr>
                    <tr>
                        <td>Peg Leg:</td>
                        <td>{pirate.pegLeg ? "yes" : "no"}</td>
                    </tr>
                    <tr>
                        <td>Eye Patch:</td>
                        <td>{pirate.eyePatch ? "yes" : "no"}</td>
                    </tr>
                    <tr>
                        <td>Hook Hand:</td>
                        <td>{pirate.hookHand ? "yes" : "no"}</td>
                    </tr>
                </tbody>
            </table>

            </div> : null
        }
        </fieldset>
    )
}

export default Detail