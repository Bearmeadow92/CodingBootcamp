import React, { useState } from 'react'
import axios from 'axios'
import { Link, useNavigate } from 'react-router-dom';



const CreateForm = (props) => {
    const [name, setName] = useState("");
    const [image_url, setImage_url] = useState("");
    const [treasureChests, setTreasurechests] = useState(0);
    const [catchPhrase, setCatchPhrase] = useState("");
    const [crewPosition, setCrewPosition] = useState("");
    const [pegLeg, setPegLeg] = useState(true);
    const [eyePatch, setEyePatch] = useState(true);
    const [hookHand, setHookHand] = useState(true);
    const [errors, setErrors] = useState([])


 const navigate = useNavigate()


//HANDLER FUNCTIONS
    const submitHandler = event => {
        event.preventDefault();
        //CREATE AND OBJECT WITH THE PRODUCT INFO
        const pirateObj= {
            name,
            image_url,
            treasureChests,
            catchPhrase,
            crewPosition,
            pegLeg,
            eyePatch,
            hookHand
        }
        //MAKE POST REQUEST TO EXPRESS WITH pirateObj
        axios.post("http://localhost:8000/api/pirates", pirateObj)
        .then(res => {
                    navigate("/" + res.data._id)
                    setName("")
                    setImage_url("")
                    setTreasurechests(0)
                    setCatchPhrase("")
                    setCrewPosition("")
                    setPegLeg(true)
                    setEyePatch(true)
                    setHookHand(true)
                })
                .catch(err => {
                    console.log(err);
                    const errorResponse = err.response.data.errors;
                    const errorArr = [];
                    for (const key of Object.keys(errorResponse)) {
                        errorArr.push(errorResponse[key].message)
                    }
                    setErrors(errorArr);
                })
    }



    return(
        <fieldset>
            <legend>CreateForm.jsx</legend>
            <h1>Add a Pirate!</h1>
            {errors.map((error, index)=>{
                return(
                    <p key={index}>{error}</p>
                )
            })}
            <Link to={'/'}><button>Crew Board</button></Link>
                <form onSubmit={submitHandler}>
                    <label>Pirate Name:</label>
                        <input type="text" onChange={(e) => setName(e.target.value)} value={name}></input>
                    <label>Add an Image URL:</label>
                        <input type="text" onChange={(e) => setImage_url(e.target.value)} value={image_url}></input>
                    <label># of Treasure Chests:</label>
                        <input type="number" onChange={(e) => setTreasurechests(e.target.value)} min="0" value={treasureChests}></input>
                    <label>Pirate Catch Phrase:</label>
                        <input type="text" onChange={(e) => setCatchPhrase(e.target.value)} value={catchPhrase}></input>
                    <label>Crew Position:</label>
                    <select onChange={(e) => setCrewPosition(e.target.value)} value={crewPosition}>
                        <option value="choose">Choose a Position</option>
                        <option value="Captain">Captain</option>
                        <option value="First Mate">First Mate</option>
                        <option value="Quarter Master">Quarter Master</option>
                        <option value="Boatswain">Boatswain</option>
                        <option value="Powder Monkey">Powder Monkey</option>
                    </select>
                    <label>Peg Leg:</label>
                        <input type="checkbox" onChange={(e) => setPegLeg(e.target.checked)} checked={pegLeg}></input>
                    <label>Eye Patch:</label>
                        <input type="checkbox" onChange={(e) => setEyePatch(e.target.checked)} checked={eyePatch}></input>
                    <label>Hook Hand:</label>
                        <input type="checkbox" onChange={(e) => setHookHand(e.target.checked)} checked={hookHand}></input>
                    <input type="submit" value="Add Pirate" />
            </form>
        </fieldset>
    )
}

export default CreateForm