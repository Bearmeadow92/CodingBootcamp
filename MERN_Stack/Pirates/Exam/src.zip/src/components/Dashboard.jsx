import React, { useEffect, useState} from 'react'
import axios from 'axios'
import { Link } from 'react-router-dom'

const Dashboard = (props) => {
    //STATE TO HOLD ALL PRODUCTS COMING FROM DATABASE
    const [allPirates, setAllPirates] = useState([])
    
    const {refreshState, refresh} = props


    useEffect(() => {
        axios.get("http://localhost:8000/api/pirates")
        .then(res => {setAllPirates(res.data)})//INCOMING PRODUCTS ARE SET TO STATE
        .catch(err => console.log(err))
    }, [refreshState])

    const deleteHandler = (id) => {
        axios.delete("http://localhost:8000/api/pirates/"+id)
        .then(res => refresh())
        .catch()
    }



    return(
        <fieldset>
            <div>
            <legend>DashboardComponent.jsx</legend>
            {
                allPirates.map((pirate, index) => {
                    return(
                        <div key={index}>
                                <h1>{pirate.name}</h1>
                                <img src={pirate.image_url} value="{name}"></img>
                                <Link to={"/" + pirate._id}><button>View Pirate</button></Link>
                            <button onClick={(e) => deleteHandler(pirate._id)}>Walk The Plank</button>

                        </div>
                    )
                })
            }
            </div>
        </fieldset>
    )
}

export default Dashboard